# CATIA 设备模型库

包含 33 个通用基座场景（`STD_`）和 12 个异形基座场景（`IRR_`）。设备几何来自已有合成装配案例，沿用装配坐标和毫米单位。基座实体和船体环境保留在原工程案例库中。

| 文件 | 用途 |
| --- | --- |
| `index.json` | 按案例 ID 查找设备模型、参数和基座生成请求 |
| `equipment.CATPart` | CATIA V5 多实体设备模型。以 STEP B-rep 导入，随件保存 `GenCore_*` 长度参数和案例 ID |
| `equipment.stp` | 与 CATPart 对应的交换几何 |
| `parameters.json` | 设备包络、安装面中心和法向、尺寸、安装标高、原始案例与 GenCore 字段 |
| `foundation_request.json` | 12 个异形基座的 StructBRep v1 生成请求，均通过 GenCore 请求编译，原始请求生成预览均返回 `preview_ready` |

## 几何与参数

设备包络和安装件包络按 `[xmin, ymin, zmin, xmax, ymax, zmax]` 排列。安装面的中心 Z 取设备与下方支承的名义接触面。通用案例安装垫属于装配接口，取垫的顶面。异形案例含设备侧安装脚、滑座、法兰等，取其底面。圆环轮廓直径描述安装件轮廓。附加示意螺栓和减振器另有记录，安装孔字段在缺少可核实孔定义时保留为空。

`installation_length_mm` 和 `installation_width_mm` 是各安装面在原装配 XY 平面的联合包络跨度。复合、多设备和多标高案例保留逐面坐标、标高和尺寸，并按安装件名称与标高写入 `mounting_groups`，供分组提取安装跨度。CATIA 中的导入实体以 B-rep 保存，`GenCore_*` 设计参数可查看和编辑，编辑这些参数不会重算设备几何。

## 接入 GenCore

- `case_matching_fields` 对应案例匹配的设备字段，`gencore_input.parameter_calculation_fields` 对应参数计算的可提取几何字段。接入时由 GenCore 运行提供 `run_id`、`base_version` 和 `premise_event_ids`，由设备资料补充 `dry_mass_kg`。重心、工况载荷和安装孔按设备资料补齐。
- 12 个异形案例可将 `foundation_request.json` 传给 `python -m gencore.structbrep.generation <request> --workspace <output> --backend preview`。随案例保存的 `details` 记录原案例对基座的补充细节。其中特定切削、倾斜等细节是否能复现取决于 StructBRep 请求实际包含的操作。
- 33 个通用案例保存安装参数和原基座分类。GenCore 当前固定几何任务 v2 的类型入口仅登记悬挂条式，因此本库未将通用案例填成统一的固定任务请求。

每个 CATPart 在保存后由 CATIA 重新打开，核验导入实体数量、案例 ID 和写入的长度参数。尺寸与布局是研究合成值。

